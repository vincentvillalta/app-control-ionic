
0.0.4 / 2014-10-06
==================

  * $http config is now sent as `config` to the tokenGetter function.
  * Update README.md

0.0.3 / 2014-10-04
==================

  * Merge pull request #3 from anongit/patch-1
  * Added missing root scope dependency.
  * Merge pull request #2 from itsananderson/examples-fix
  * Update examples to include module dependency
  * Update README.md
  * Update README.md
  * Update README.md
  * Update README.md
  * Fixed dist
  * Merge pull request #1 from gdi2290/patch-1
  * docs(readme): update examples for 1.3+
  * Added installation
  * Added v0.0.2
  * Added version
